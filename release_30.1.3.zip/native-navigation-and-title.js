"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NativeNavigationAndTitle = void 0;
const constants_1 = require("./constants");
const utils_1 = require("./utils");
/**
 * Класс, отвечающий за взаимодействие с нативными элементами в приложении – заголовком
 * и нативной кнопкой назад.
 */
class NativeNavigationAndTitle {
    constructor(b2n, pageId, initialNativeTitle = '', handleWindowRedirect) {
        this.b2n = b2n;
        this.nativeHistoryStack = [''];
        this.numOfBackSteps = 1;
        // Тут сохраняются параметры, которые в последний раз были отправлены в приложение.
        // Просто, чтобы не слать одинаковые сигналы в приложение.
        this.lastSetPageSettingsParams = '';
        this.handleBack = this.handleBack.bind(this);
        this.handleWindowRedirect = handleWindowRedirect;
        const previousState = !!sessionStorage.getItem(constants_1.PREVIOUS_NATIVE_NAVIGATION_AND_TITLE_STATE_STORAGE_KEY);
        if (pageId) {
            this.supportSharedSession(pageId, initialNativeTitle);
        }
        else if (previousState) {
            this.restorePreviousState();
        }
        else {
            this.setInitialView(initialNativeTitle);
        }
    }
    /**
     * Метод, вызывающий `history.back()` или закрывающий вебвью, если нет записей
     * в истории переходов.
     */
    goBack() {
        this.goBackAFewSteps(-1, true);
    }
    /**
     * Метод, вызывающий history.go(-колл. шагов назад) и модифицирует внутреннее
     * состояние, чтобы в дальнейшем зарегистририровать этот переход в приложении.
     *
     * @param stepsNumber Количество шагов назад.
     *  Возможно передача как положительного, так и отрицательного числа.
     *  0 будет проигнорирован.
     * @param autocloseWebview Флаг – закрывать ли вебвью автоматически,
     *  если переданное кол-во шагов будет больше, чем записей в истории.
     */
    goBackAFewSteps(stepsNumber, autocloseWebview = false) {
        if (!stepsNumber) {
            return;
        }
        const stepsToBack = Math.abs(stepsNumber);
        const maxStepsToBack = this.nativeHistoryStack.length - 1;
        if (stepsToBack > maxStepsToBack) {
            if (autocloseWebview) {
                this.b2n.closeWebview();
                return;
            }
            this.numOfBackSteps = maxStepsToBack;
        }
        else {
            this.numOfBackSteps = stepsToBack;
        }
        window.history.go(-this.numOfBackSteps);
    }
    /**
     * Метод вызывает `src/shared/utils/handle-redirect` из `newclick-host-ui`
     * и регистрирует этот переход в приложении, чтобы кнопка «Назад» в Нативе вызывала
     * переход назад в вебе.
     */
    handleRedirect(pageTitleOrPath, appName, path, params) {
        if (appName) {
            this.handleWindowRedirect(appName, path, params);
        }
        else {
            const { appName: extractedAppName, path: extractedPath, query: extractedQuery, } = (0, utils_1.extractAppNameRouteAndQuery)(pageTitleOrPath);
            this.handleWindowRedirect(extractedAppName, extractedPath, extractedQuery);
        }
        const title = appName ? pageTitleOrPath : '';
        this.nativeHistoryStack.push(title);
        this.syncHistoryWithNative(title, 'navigation');
    }
    /**
     * Информирует натив, что веб находится на первом экране (сбрасывает историю переходов, не влияя на браузерную
     * историю), а значит следующее нажатие на кнопку "Назад" в нативне закроет вебвью.
     *
     * @param pageTitle Заголовок, который нужно отрисовать в нативе.
     */
    setInitialView(pageTitle = '') {
        this.nativeHistoryStack = [pageTitle];
        this.syncHistoryWithNative(pageTitle, 'initialization');
        this.reassignPopstateListener();
    }
    /**
     * Метод для смены заголовка в нативе без влияния на историю переходов.
     *
     * @param pageTitle Заголовок, который нужно отрисовать в нативе.
     */
    setTitle(pageTitle) {
        this.nativeHistoryStack[this.nativeHistoryStack.length - 1] = pageTitle;
        this.syncHistoryWithNative(pageTitle, 'title-replacing');
    }
    /**
     * Метод для открытия второго web приложения в рамках
     * одной вебвью сессии
     * сохраняет все текущее состояние текущего экземпляра bridgeToAm и AmNavigationAndTitle в sessionStorage, а
     * так же наполняет url необходимыми query параметрами. Работает только в Android окружении.
     * В IOS окружении будет открыто новое webview поверх текущего.
     * @param url адрес второго web приложения к которому перед переходом на него будут добавлены
     * все initial query параметры от натива и параметр nextPageId (Android)
     */
    navigateInsideASharedSession(url) {
        if (this.b2n.environment === 'ios') {
            this.b2n.nativeFallbacks.visitExternalResource(url);
            return;
        }
        // В b2n этот метод отмечен модификатором доступа private, но тут его нужно вызвать
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        this.b2n.saveCurrentState();
        window.location.assign(this.prepareExternalLinkBeforeOpen(url));
    }
    /**
     * ПОКА НЕ ИСПОЛЬЗОВАТЬ В ПРОДЕ (МЕТОД НЕ РАБОТАЕТ КОРРЕКТНО НА ANDROID)
     * НА ANDROID ПРИ ПЕРЕЗАГРУЗКЕ СТРАНИЦЫ В ИСТРИЮ ЛОЖИТСЯ + ЕЩЕ ОДИН ЛИШНИЙ ЭЛЕМЕНТ
     * Данный метод будет дорабатываться отдельной задачей
     * Безопасный способ для перезагрузки страницы.
     * Производит предварительное сохранение текущего состояния
     * BridgeToNative и NativeNavigationAndTitle перед вызовом location.reload()
     */
    reloadPage() {
        // В b2n этот метод отмечен модификатором доступа private, но тут его нужно вызвать
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        this.b2n.saveCurrentState();
        window.location.reload();
    }
    /**
     * Метод для сохранения текущего состояния NativeNavigationAndTitle в sessionStorage.
     */
    saveCurrentState() {
        const currentState = {
            title: this.nativeHistoryStack[this.nativeHistoryStack.length - 1],
            nativeHistoryStack: this.nativeHistoryStack,
        };
        sessionStorage.setItem(constants_1.PREVIOUS_NATIVE_NAVIGATION_AND_TITLE_STATE_STORAGE_KEY, JSON.stringify(currentState));
    }
    /**
     * Метод, вычисляющий `pageId`, который нужно послать в приложение
     * для правильной синхронизации с нативной-кнопкой "Назад".
     *
     * @param purpose Цель взаимодействия с приложением.
     * @returns Правильный pageId.
     */
    getNativePageId(purpose) {
        function assertUnreachable(val) {
            throw new Error(`Unexpected value "${val}"`);
        }
        let pageId;
        switch (purpose) {
            case 'initialization':
                pageId = this.getNativePageIdForInitialization();
                break;
            case 'navigation':
                pageId = this.getNativePageIdForNavigation();
                break;
            case 'title-replacing':
                pageId = this.getNativePageIdForTitleReplacing();
                break;
            default:
                assertUnreachable(purpose);
        }
        return pageId;
    }
    /**
     * Вспомогательный метод для `getNativePageId` initialization кейса.
     *
     * @returns Правильный pageId.
     */
    getNativePageIdForInitialization() {
        // * В iOS для "первой" страницы не нужно слать `pageId`.
        // * В Android важно, чтобы `pageId` "первой" страницы
        //  всегда был одинаковый.
        return this.b2n.environment === 'ios' ? null : 1;
    }
    /**
     * Вспомогательный метод для `getNativePageId` navigation кейса.
     *
     * @returns Правильный pageId.
     */
    getNativePageIdForNavigation() {
        const stackSize = this.nativeHistoryStack.length;
        // Нажимая на кнопку назад, можно дойти до "первой" страницы,
        // в iOS для "первой" страницы не нужно слать `pageId`
        return this.b2n.environment === 'ios' && stackSize <= 1 ? null : stackSize;
    }
    /**
     * Вспомогательный метод для `getNativePageId` only-title кейса.
     *
     * @returns Правильный pageId.
     */
    getNativePageIdForTitleReplacing() {
        const stackSize = this.nativeHistoryStack.length;
        if (this.b2n.environment === 'android') {
            // Для смены заголовка в Андроид просто повторяем текущий `pageId`.
            // В отличии от iOS, если не послать `pageId` первой страницы,
            // Вебвью не будет закрываться по клику на нативный «Назад».
            return stackSize <= 1 ? 1 : stackSize;
        }
        // Если в iOS не послать `pageId`, следующее нажатие на
        // нативную кнопку назад закроет webview.
        return stackSize <= 1 ? null : stackSize;
    }
    /**
     * Обработчик для `window.onpopstate` события. Который сработает
     * после нажатия на кнопку "Назад" в нативе, вызова `history.back()` и `history.go(-x)`.
     */
    handleBack() {
        const previousState = !!sessionStorage.getItem(constants_1.PREVIOUS_NATIVE_NAVIGATION_AND_TITLE_STATE_STORAGE_KEY);
        if (previousState) {
            // В b2n этот метод отмечен модификатором доступа private дабы не торчал наружу, но тут его нужно вызвать
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
            this.b2n.restorePreviousState();
        }
        this.nativeHistoryStack = this.nativeHistoryStack.slice(0, -this.numOfBackSteps);
        this.numOfBackSteps = 1;
        if (this.nativeHistoryStack.length < 1) {
            this.b2n.closeWebview();
            return;
        }
        const pageTitle = this.nativeHistoryStack[this.nativeHistoryStack.length - 1];
        this.syncHistoryWithNative(pageTitle, 'navigation');
    }
    /**
     * Синхронизирует состояние истории переходов и заголовок с приложением.
     *
     * @param pageTitle Заголовок, который нужно отрисовать в приложении.
     * @param purpose Цель взаимодействия с приложением.
     */
    syncHistoryWithNative(pageTitle, purpose) {
        var _a;
        const pageId = this.getNativePageId(purpose);
        if (this.b2n.environment === 'android') {
            const pageSettingsObj = { pageTitle };
            if (pageId) {
                pageSettingsObj.pageId = pageId;
            }
            const paramsToSend = JSON.stringify(pageSettingsObj);
            if (this.lastSetPageSettingsParams !== paramsToSend) {
                (_a = this.b2n.AndroidBridge) === null || _a === void 0 ? void 0 : _a.setPageSettings(paramsToSend);
                this.lastSetPageSettingsParams = paramsToSend;
            }
        }
        else {
            const pageTitleStr = `?pageTitle=${encodeURIComponent(pageTitle)}`;
            const pageIdStr = pageId ? `&pageId=${pageId}` : '';
            const paramsToSend = `ios:setPageSettings/${pageTitleStr + pageIdStr}`;
            if (this.lastSetPageSettingsParams !== paramsToSend) {
                window.location.replace(paramsToSend);
                this.lastSetPageSettingsParams = paramsToSend;
            }
        }
    }
    /**
     * Метод для перехода в веб из другого веб приложения в рамках
     * одной вебвью сессии
     * @param pageId - Номер текущего page который нужно отправить в приложение
     * @param title - Title текущего page который нужно отправить в приложение
     */
    supportSharedSession(pageId, title) {
        this.nativeHistoryStack = new Array(pageId).fill('');
        this.syncHistoryWithNative(title, 'title-replacing');
        this.reassignPopstateListener();
    }
    /**
     * Восстанавливает свое предыдущее состояние nativeHistoryStack и title из sessionStorage
     */
    restorePreviousState() {
        const previousState = JSON.parse(sessionStorage.getItem(constants_1.PREVIOUS_NATIVE_NAVIGATION_AND_TITLE_STATE_STORAGE_KEY) || '');
        this.nativeHistoryStack = previousState.nativeHistoryStack;
        this.syncHistoryWithNative(previousState.title, 'title-replacing');
        this.reassignPopstateListener();
        sessionStorage.removeItem(constants_1.PREVIOUS_NATIVE_NAVIGATION_AND_TITLE_STATE_STORAGE_KEY);
    }
    /**
     *  Вспомогательный метод для setInitialView, supportSharedSession
     *  переназначает обработчик @handleBack для `window.onpopstate` события
     */
    reassignPopstateListener() {
        window.removeEventListener('popstate', this.handleBack);
        window.addEventListener('popstate', this.handleBack);
    }
    /**
     * Вспомогательный метод для navigateInsideASharedSession.
     * Подготавливает внешнюю ссылку в рамках контракта для совместной работы веб-приложений в
     * рамках одной вебвью сессии
     * @param url - url иного веб приложения
     * @return подготовленная согласно контракту ссылка на иное веб приложение с initial query
     * параметрами от нативе, а так же nextPageId
     */
    prepareExternalLinkBeforeOpen(url) {
        const currentPageId = this.nativeHistoryStack.length;
        const divider = new URL(url).searchParams.toString() ? '&' : '?';
        const link = new URL(`${url}${divider}${this.b2n.originalWebviewParams}`);
        link.searchParams.set('nextPageId', (currentPageId + 1).toString());
        return link.toString();
    }
}
exports.NativeNavigationAndTitle = NativeNavigationAndTitle;
