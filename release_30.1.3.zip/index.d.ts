import { NativeFallbacks } from './native-fallbacks';
import { HandleRedirect, NativeNavigationAndTitle } from './native-navigation-and-title';
import type { Environment, NativeFeatureKey, NativeFeaturesFts, NativeParams } from './types';
declare type Theme = 'light' | 'dark';
/**
 * Этот класс - абстракция для связи веб приложения с нативом и предназначен ТОЛЬКО
 * для использования в вебвью окружении.
 */
export declare class BridgeToNative {
    nativeFeaturesFts: NativeFeaturesFts;
    readonly AndroidBridge: {
        setPageSettings: (params: string) => void;
    } | undefined;
    readonly environment: Environment;
    readonly nativeFallbacks: NativeFallbacks;
    private nextPageId;
    private _nativeNavigationAndTitle;
    private _originalWebviewParams;
    private _appVersion;
    private _iosAppId?;
    private _theme;
    private _handleRedirect;
    constructor(nativeFeaturesFts: NativeFeaturesFts, handleRedirect: HandleRedirect, nativeParams?: NativeParams);
    get theme(): Theme;
    get appVersion(): string;
    get iosAppId(): string | undefined;
    get nativeNavigationAndTitle(): NativeNavigationAndTitle;
    get originalWebviewParams(): string;
    /**
     * Метод, проверяющий, можно ли использовать нативную функциональность в текущей версии приложения.
     *
     * @param feature Название функциональности, которую нужно проверить.
     */
    canUseNativeFeature(feature: NativeFeatureKey): boolean;
    /**
     * Метод, отправляющий сигнал нативу, что нужно закрыть текущее вебвью.
     */
    closeWebview(): void;
    /**
     * Сравнивает текущую версию приложения с переданной.
     *
     * @param versionToCompare Версия, с которой нужно сравнить текущую.
     * @returns `true` – текущая версия больше или равняется переданной,
     *  `false` – текущая версия ниже.
     */
    isCurrentVersionHigherOrEqual(versionToCompare: string): boolean;
    /**
     * Сохраняет текущее состояние BridgeToNative в sessionStorage.
     * Так же сохраняет текущее состояние nativeNavigationAndTitle.
     */
    private saveCurrentState;
    /**
     * Возвращает схему приложения в iOS окружении, на основе версии.
     *
     * @param knownIosAppId Тип iOS приложения, если он известен.
     * @returns Тип приложения, `undefined` для Android окружения.
     */
    private getIosAppId;
    /**
     * Восстанавливает свое предыдущее состояние из sessionStorage
     */
    private restorePreviousState;
}
export {};
