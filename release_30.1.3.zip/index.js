"use strict";
/* eslint-disable no-underscore-dangle */
Object.defineProperty(exports, "__esModule", { value: true });
exports.BridgeToNative = void 0;
const constants_1 = require("./constants");
const native_fallbacks_1 = require("./native-fallbacks");
const native_navigation_and_title_1 = require("./native-navigation-and-title");
const utils_1 = require("./utils");
/**
 * Этот класс - абстракция для связи веб приложения с нативом и предназначен ТОЛЬКО
 * для использования в вебвью окружении.
 */
class BridgeToNative {
    constructor(nativeFeaturesFts = { 'linksInBrowserAndroid': true, 'linksInBrowserIos': true }, handleRedirect, nativeParams) {
        this.nativeFeaturesFts = nativeFeaturesFts;
        // Webview, запущенное в Android окружении имеет объект `Android` в window.
        this.AndroidBridge = window.Android;
        this.environment = this.AndroidBridge ? 'android' : 'ios';
        const previousState = !!sessionStorage.getItem(constants_1.PREVIOUS_B2N_STATE_STORAGE_KEY);
        if (previousState) {
            this.restorePreviousState();
            this.nativeFallbacks = new native_fallbacks_1.NativeFallbacks(this);
            return;
        }
        this._appVersion =
            nativeParams && (0, utils_1.isValidVersionFormat)(nativeParams === null || nativeParams === void 0 ? void 0 : nativeParams.appVersion)
                ? nativeParams.appVersion
                : '0.0.0';
        this._iosAppId = this.getIosAppId(nativeParams === null || nativeParams === void 0 ? void 0 : nativeParams.iosAppId);
        this._theme = (nativeParams === null || nativeParams === void 0 ? void 0 : nativeParams.theme) === 'dark' ? 'dark' : 'light';
        this._originalWebviewParams = (nativeParams === null || nativeParams === void 0 ? void 0 : nativeParams.originalWebviewParams) || '';
        this._nativeNavigationAndTitle = new native_navigation_and_title_1.NativeNavigationAndTitle(this, nativeParams ? nativeParams.nextPageId : null, nativeParams === null || nativeParams === void 0 ? void 0 : nativeParams.title, handleRedirect);
        this._handleRedirect = handleRedirect;
        this.nextPageId = nativeParams ? nativeParams.nextPageId : null;
        this.nativeFallbacks = new native_fallbacks_1.NativeFallbacks(this);
    }
    get theme() {
        return this._theme;
    }
    get appVersion() {
        return this._appVersion;
    }
    get iosAppId() {
        return this._iosAppId;
    }
    get nativeNavigationAndTitle() {
        return this._nativeNavigationAndTitle;
    }
    get originalWebviewParams() {
        return this._originalWebviewParams;
    }
    /**
     * Метод, проверяющий, можно ли использовать нативную функциональность в текущей версии приложения.
     *
     * @param feature Название функциональности, которую нужно проверить.
     */
    canUseNativeFeature(feature) {
        const { nativeFeatureFtKey, fromVersion } = constants_1.nativeFeaturesFromVersion[this.environment][feature];
        if (nativeFeatureFtKey && !this.nativeFeaturesFts[nativeFeatureFtKey]) {
            return false;
        }
        return this.isCurrentVersionHigherOrEqual(fromVersion);
    }
    /**
     * Метод, отправляющий сигнал нативу, что нужно закрыть текущее вебвью.
     */
    // eslint-disable-next-line class-methods-use-this
    closeWebview() {
        const originalPageUrl = new URL(window.location.href);
        originalPageUrl.searchParams.set(constants_1.CLOSE_WEBVIEW_SEARCH_KEY, constants_1.CLOSE_WEBVIEW_SEARCH_VALUE);
        window.location.href = originalPageUrl.toString();
    }
    /**
     * Сравнивает текущую версию приложения с переданной.
     *
     * @param versionToCompare Версия, с которой нужно сравнить текущую.
     * @returns `true` – текущая версия больше или равняется переданной,
     *  `false` – текущая версия ниже.
     */
    isCurrentVersionHigherOrEqual(versionToCompare) {
        if (!(0, utils_1.isValidVersionFormat)(versionToCompare)) {
            return false;
        }
        const matchPattern = /(\d+)\.(\d+)\.(\d+)/;
        const [, ...appVersionComponents] = this._appVersion.match(matchPattern); // Формат версии проверен в конструкторе, можно смело убирать `null` из типа.
        const [, ...versionToCompareComponents] = versionToCompare.match(matchPattern);
        for (let i = 0; i < appVersionComponents.length; i++) {
            if (appVersionComponents[i] !== versionToCompareComponents[i]) {
                return appVersionComponents[i] >= versionToCompareComponents[i];
            }
        }
        return true;
    }
    /**
     * Сохраняет текущее состояние BridgeToNative в sessionStorage.
     * Так же сохраняет текущее состояние nativeNavigationAndTitle.
     */
    saveCurrentState() {
        // В nativeNavigationAndTitle этот метод отмечен модификатором доступа private дабы не торчал наружу, но тут его нужно вызвать
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        this._nativeNavigationAndTitle.saveCurrentState();
        const currentState = {
            appVersion: this._appVersion,
            theme: this._theme,
            nextPageId: this.nextPageId,
            originalWebviewParams: this._originalWebviewParams || '',
            iosAppId: this._iosAppId,
        };
        sessionStorage.setItem(constants_1.PREVIOUS_B2N_STATE_STORAGE_KEY, JSON.stringify(currentState));
    }
    /**
     * Возвращает схему приложения в iOS окружении, на основе версии.
     *
     * @param knownIosAppId Тип iOS приложения, если он известен.
     * @returns Тип приложения, `undefined` для Android окружения.
     */
    getIosAppId(knownIosAppId) {
        if (this.environment !== 'ios') {
            return undefined;
        }
        if (knownIosAppId) {
            return knownIosAppId;
        }
        const keys = Object.keys(constants_1.versionToIosAppId);
        const rightKey = [...keys].reverse().find((version) => this.isCurrentVersionHigherOrEqual(version)) ||
            keys[0];
        return atob(constants_1.versionToIosAppId[rightKey]);
    }
    /**
     * Восстанавливает свое предыдущее состояние из sessionStorage
     */
    restorePreviousState() {
        const previousState = JSON.parse(sessionStorage.getItem(constants_1.PREVIOUS_B2N_STATE_STORAGE_KEY) || '');
        this._appVersion = previousState.appVersion;
        this._iosAppId = previousState.iosAppId;
        this._theme = previousState.theme;
        this._originalWebviewParams = previousState.originalWebviewParams;
        this.nextPageId = previousState.nextPageId;
        this._nativeNavigationAndTitle = new native_navigation_and_title_1.NativeNavigationAndTitle(this, previousState.nextPageId, '', this._handleRedirect);
        sessionStorage.removeItem(constants_1.PREVIOUS_B2N_STATE_STORAGE_KEY);
    }
}
exports.BridgeToNative = BridgeToNative;
