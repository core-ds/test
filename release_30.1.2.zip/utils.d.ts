/**
 * Разделяет веб ссылку на компоненты
 * @param route внутренний путь для навигации
 * @return объект с appName, route, query
 */
export declare const extractAppNameRouteAndQuery: (route: string) => {
    appName: string;
    path: string;
    query: Record<string, string> | undefined;
};
/**
 * Возвращает экземпляр `URL` из ссылки, докидывая `https://` при отсутствии.
 */
export declare const getUrlInstance: (link: string) => URL;
/**
 * Проверяет, что переданная строка содержит версию приложения в правильном формате.
 *
 * @param version Строка с версией для проверки.
 * @returns Правильный формат или нет.
 */
export declare const isValidVersionFormat: (version?: string | undefined) => boolean;
