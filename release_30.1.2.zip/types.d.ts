export declare type NativeParams = {
    appVersion: string;
    title?: string;
    iosAppId?: string;
    theme: string;
    nextPageId: number | null;
    originalWebviewParams: string;
};
declare type NativeFeatureFtKey = 'linksInBrowserAndroid' | 'linksInBrowserIos';
export declare type NativeFeaturesFts = Record<NativeFeatureFtKey, boolean>;
export declare type NativeFeatureKey = 'geolocation' | 'linksInBrowser';
declare type NativeFeaturesParams = Readonly<Record<NativeFeatureKey, {
    nativeFeatureFtKey?: NativeFeatureFtKey;
    fromVersion: string;
}>>;
export declare type NativeFeaturesFromVersion = Readonly<{
    android: NativeFeaturesParams;
    ios: NativeFeaturesParams;
}>;
export declare type Environment = 'android' | 'ios';
export declare type WebViewWindow = Window & {
    Android?: {
        setPageSettings: (params: string) => void;
    };
    handleRedirect?: (appName: string, path?: string, params?: Record<string, string>) => VoidFunction;
};
export declare type PdfType = 'pdfFile' | 'base64' | 'binary';
export declare type PreviousBridgeToNativeState = Omit<NativeParams, 'title' | 'theme'> & {
    theme: 'dark' | 'light';
};
export declare type PreviousNativeNavigationAndTitleState = {
    nativeHistoryStack: string[];
    title: string;
};
export {};
